YOLO model files are downloaded automatically by Ultralytics when a model name such as `yolo11n.pt` is used.

Do not commit large model files to GitHub unless your course specifically requires it.
