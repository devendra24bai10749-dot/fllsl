# PROJECT REPORT

# Real-Time Object Detection Using YOLO and OpenCV

## 1. Introduction

Object detection is an important task in Computer Vision. It allows a computer to identify objects in an image or video and determine where those objects are located.

This project implements a Real-Time Object Detection System using the YOLO object detection framework and OpenCV. The application can process a live webcam stream, image files, and video files. For each detected object, the system draws a bounding box and displays the object class and confidence score.

The project is designed to be executable from the command line so that an evaluator can install the dependencies and run it without requiring a GUI-based development environment.

## 2. Problem Statement

Manual identification of objects in video streams is time-consuming and difficult to scale. A computer vision system is required that can automatically detect common objects in real time and provide their location and confidence.

## 3. Objectives

1. To implement object detection using YOLO.
2. To process images, videos, and webcam streams.
3. To use OpenCV for video/image input and output processing.
4. To draw bounding boxes around detected objects.
5. To display object names and confidence scores.
6. To provide a command-line interface.
7. To create a reproducible GitHub-ready project.

## 4. Existing System

Traditional image processing approaches often depend on manually designed features, thresholding, contours, or separate classifiers. These approaches may work for controlled environments but can become difficult to maintain when object appearance, lighting, scale, and background change.

Modern deep-learning object detectors learn useful visual features from training data and can detect multiple objects in a single frame.

## 5. Proposed System

The proposed system uses a pretrained YOLO model. The input may be a webcam, image, or video. Each frame is passed to the model, which predicts object classes, bounding boxes, and confidence scores.

OpenCV is then used to draw the detection results and display or save the processed output.

## 6. Technologies Used

### Python

Python is used as the main programming language because it provides a simple syntax and strong Computer Vision/AI libraries.

### YOLO

YOLO (You Only Look Once) is a deep-learning object detection approach that predicts object locations and classes from an image.

### Ultralytics

The Ultralytics Python package provides the YOLO model interface used by the application.

### OpenCV

OpenCV is used for:

- Reading images
- Capturing webcam frames
- Reading video files
- Drawing bounding boxes
- Displaying results
- Saving output

## 7. Hardware Requirements

Recommended:

- 4 GB RAM minimum
- 8 GB RAM recommended
- Dual-core processor or better
- Webcam for real-time testing
- GPU optional

## 8. Software Requirements

- Windows/Linux/macOS
- Python 3.10+
- Ultralytics
- OpenCV
- Internet connection for first-time model download

## 9. System Architecture

```text
+-------------------+
| Input Source      |
| Webcam/Image/Video|
+---------+---------+
          |
          v
+-------------------+
| OpenCV Input      |
| Frame Acquisition |
+---------+---------+
          |
          v
+-------------------+
| YOLO Model        |
| Object Detection  |
+---------+---------+
          |
          v
+----------------------------+
| Predictions                |
| Class + Bounding Box +     |
| Confidence                 |
+-------------+--------------+
              |
              v
+----------------------------+
| OpenCV Annotation          |
| Draw boxes and labels      |
+-------------+--------------+
              |
              v
+----------------------------+
| Display / Save Output      |
+----------------------------+
```

## 10. Methodology

### Step 1: Input Acquisition

The application receives a source from the command line.

Examples:

```text
0
input/sample.jpg
input/video.mp4
```

A numeric source represents a webcam index.

### Step 2: Frame Reading

OpenCV reads the image or video frame. For webcam and video input, frames are processed sequentially.

### Step 3: YOLO Inference

The frame is passed to the YOLO model. The model predicts:

- Object class
- Bounding box coordinates
- Confidence score

### Step 4: Filtering

Predictions below the configured confidence threshold are ignored.

### Step 5: Annotation

OpenCV draws a rectangle around each detected object and writes the class name and confidence.

Example:

```text
person 0.91
```

### Step 6: Output

The processed frame is displayed. For image/video sources, the user can optionally provide an output path to save the result.

## 11. Algorithm

1. Start the application.
2. Read command-line arguments.
3. Load the YOLO model.
4. Identify the input source.
5. Open webcam/image/video.
6. Read a frame.
7. Send the frame to YOLO.
8. Obtain detections.
9. Filter detections using confidence threshold.
10. Draw bounding boxes and labels.
11. Display the frame.
12. Optionally save the frame/video.
13. Repeat until input ends or the user presses Q.
14. Release resources.
15. End.

## 12. Implementation

The main files are:

### `main.py`

Handles:

- Command-line arguments
- Model loading
- Input-source selection
- Program execution

### `detect.py`

Handles:

- Image detection
- Video/webcam detection
- Drawing detection results

### `config.py`

Stores default configuration values such as model name, confidence threshold, and image size.

## 13. Execution Commands

### Webcam

```bash
python main.py --source 0
```

### Image

```bash
python main.py --source input/sample.jpg
```

### Video

```bash
python main.py --source input/video.mp4
```

### Save Image Result

```bash
python main.py --source input/sample.jpg --output output/result.jpg
```

### Save Video Result

```bash
python main.py --source input/video.mp4 --output output/result.mp4
```

## 14. Results

The system produces annotated images/video frames containing:

- Bounding boxes
- Detected object names
- Confidence scores

Typical objects that can be detected depend on the pretrained model and its training classes. Common examples include people, cars, bottles, phones, chairs, and other everyday objects.

### Screenshot Placeholder 1

Insert a screenshot of webcam detection here.

### Screenshot Placeholder 2

Insert a screenshot of image detection here.

### Screenshot Placeholder 3

Insert a screenshot of video detection here.

## 15. Advantages

- Simple command-line execution
- Supports multiple input types
- Uses a pretrained object detector
- Real-time webcam capability
- Easy to extend
- Suitable for educational Computer Vision work

## 16. Limitations

- Performance depends on hardware.
- CPU inference can be slower than GPU inference.
- Detection accuracy depends on the pretrained model.
- Objects outside the model's trained classes may not be detected.
- Extreme lighting, occlusion, or blur can reduce accuracy.

## 17. Future Scope

The project can be extended with:

1. Object tracking.
2. Custom YOLO training.
3. Real-time FPS monitoring.
4. Object counting.
5. Traffic monitoring.
6. Restricted-area alerts.
7. CSV/database logging.
8. Distance estimation.
9. Multi-camera support.
10. Deployment as a web service.

## 18. Conclusion

The project demonstrates how modern deep-learning object detection can be combined with OpenCV to create a practical Computer Vision application.

The implemented system accepts webcam, image, and video sources, detects objects using YOLO, and displays bounding boxes, class labels, and confidence scores. Its command-line interface makes the project reproducible and suitable for GitHub-based academic evaluation.

## 19. References

1. Ultralytics documentation: YOLO model and Python usage.
2. OpenCV documentation: image and video processing.
3. Redmon, J., Divvala, S., Girshick, R., and Farhadi, A., "You Only Look Once: Unified, Real-Time Object Detection."
4. Computer Vision and Deep Learning course materials.
