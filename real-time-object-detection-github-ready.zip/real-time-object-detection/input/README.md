Place your own test images or videos in this folder.

Example:
    python main.py --source input/sample.jpg
    python main.py --source input/video.mp4
